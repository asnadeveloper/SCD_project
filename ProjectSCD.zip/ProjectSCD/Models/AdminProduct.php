<?php

namespace App\Models;
use  App\Models\Order;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Admin;

class AdminProduct extends Model
{
    use HasFactory;
    protected $fillable=['name', 'description', 'price','image'];
   

    public function orders()
    {
        return $this->hasMany(Order::class);
    }
    public function admin()
    {
        return $this->belongsTo(Admin::class);
    }
}


