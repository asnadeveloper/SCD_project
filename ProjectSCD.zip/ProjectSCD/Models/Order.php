<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\AdminProduct;
use App\Models\UserProject;

class Order extends Model
{
    use HasFactory;
    protected $fillable=[
        'email',
        'firstname',
        'lastname',
        'address',
        'city',
        'state',
        'zipcode',
        'country',
        'number',
        'product_id',
        'user_id',

    ];

    public function products()
    {
        return $this->hasMany(AdminProduct::class);
    }
    public function user()
    {
        return $this->belongsTo(UserProject::class);
    }
}
