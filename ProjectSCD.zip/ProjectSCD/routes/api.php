<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminProductController;
use App\Http\Controllers\UserProjectController;
use App\Http\Controllers\OrderController;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/
Route::post('store-admin',[AdminController::class, 'store']);
Route::post('store-adminProduct',[AdminProductController::class, 'store']);
Route::post('store-user',[UserProjectController::class, 'store']);
Route::post('store-order',[OrderController::class, 'store']);


Route::get('indexproduct',[AdminProductController::class, 'index']);
Route::delete('deleteproduct/{id}',[AdminProductController::class, 'destroy']);

Route::get('index',[AdminController::class, 'index']);

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
