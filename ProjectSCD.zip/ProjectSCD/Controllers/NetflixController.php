<?php

namespace App\Http\Controllers;

use App\Models\Netflix;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;

class NetflixController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $netflix=Netflix::all();
        return view('index', compact('netflix'));
    }

   
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('upload');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        
        $file = $request->file('file_var');
        $file_name = $file->getClientOriginalName();
        $file->move('uploads', $file_name);


        $data = $request->validate(
            [
            'name'=>'required',
            'description'=>'required',
            'category'=>'required', 
            // 'file_var'=>'required'

        ]);
        // dd('sdfsdf');
        $data['file_var'] = $file_name;
        $data['user_id'] = Auth::id();

        Netflix::create($data);
        return redirect(url('index-page'));

    }

    /**
     * Display the specified resource.
     */
    public function show(Netflix $netflix)
    {
        $netflixes = Netflix::where('user_id', $netflix->user_id)->get();
        return view('user_page', compact('netflixes'));
    }

 

    

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Netflix $netflix)
    {
        return view('edit', compact('netflix'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Netflix $netflix)
    {
        $file = $request->file('file_var');
        $file_name = $file->getClientOriginalName();
        $file->move('uploads', $file_name);


        $data = $request->validate(
            [
            'name'=>'required',
            'description'=>'required',
            'category'=>'required', 
            // 'file_var'=>'required'

        ]);
        // dd('sdfsdf');
        $data['file_var'] = $file_name;
        $data['user_id'] = Auth::id();

        $netflix->update($data);
        return redirect(url('index-page'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Netflix $netflix)
    {
        $netflix->delete();
        return redirect(url('index-page'));
    }
}
