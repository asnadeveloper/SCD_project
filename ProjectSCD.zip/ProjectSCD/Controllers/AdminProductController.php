<?php

namespace App\Http\Controllers;

use App\Models\AdminProduct;
use Illuminate\Http\Request;

class AdminProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $products=AdminProduct::get();
        return $products;
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $file = $request->file('image');
        $file_name = $file->getClientOriginalName();
        $file->move('uploads', $file_name);

        $data=$request->validate(
            [
                'name' => 'required',
                'price' => 'required',
                'description' => 'required',
               
            ]); 

            $data['image'] = $file_name;
           

            
    
            AdminProduct::create($data);
    }

    /**
     * Display the specified resource.
     */
    public function show(AdminProduct $adminProduct)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(AdminProduct $adminProduct)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, AdminProduct $adminProduct)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(AdminProduct $adminProduct)
    {
        // return("helllllo");
        // dd($adminProduct);
        $adminProduct->delete();
    }
}
