<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Document</title>
</head>
<style>

fieldset
{
    border-radius:20px;
    width:30%;
}
input{
    border-radius:30px;
    height: 20px;
    width: 150px;
}

</style>
<body bgcolor="#AFE4DE">

    <center>

    <u><b><h1>Upload Your File</h1></b></u>
<fieldset>
    <legend>File Upload</legend>
    <form action="store-file" method="post" enctype="multipart/form-data" >
              
        @csrf

     Name  <input type="text" name="name" id="">
       <br></br><br></br>
       Description  <input type="text" name="description" id="">
      <br></br><br></br>
     Category <select name="category" id="">
        <option value="Sports">Sports</option>
        <option value="Entertainment">Entertainment</option>
        <option value="Politics">Politics</option>
     </select>
     <br></br><br></br>
     Upload File <input type="file" name="file_var" id="">
     <br></br><br></br>
     <input type="submit" value="Upload">
     </form>
</fieldset>
</center>
</body>
</html>