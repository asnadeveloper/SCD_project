<?php use Illuminate\Support\Facades\Auth; ?>

<!DOCTYPE html>
<html lang="en">
   <head>
  
    <title>Document</title>
    </head>

  <body bgcolor="#AFE4DE">

    <h1> <b><u>My Files</b></u></h1>
   <table border="1">

    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Description</th>
        <th>Category</th>
        <th>File Name</th>
        <th>Video</th>
        <th>Actions</th>
    </tr>
     @forelse ($netflix as $key=>$netflix)
        <tr>
            <td> {{$key+1}} </td>
            <td> {{$netflix->name}} </td>
            <td> {{$netflix->description}} </td>
            <td> {{$netflix->category}} </td>
            <td> {{$netflix->file_var}} </td>
            <td><video width="320" height="240" controls>
         <source src="{{ asset('uploads/' . $netflix->file_var) }}" type="video/mp4">
                   </video></td>
             <td> <a href="destroy-file/{{$netflix->id}}">Delete</a></td>
                   
             <td> <a href="edit-file/{{$netflix->id}}">Edit/Update</a>
                  
                  </td>
        </tr>
     @empty
            no data found
     @endforelse 


   </table>


  </body>
</html>