<?php use Illuminate\Support\Facades\Auth; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  
    <title>Document</title>
</head>
<style>
   .profile
   {
    position:absolute;
    justify-content:right;
    border:1px solid black;
    height: 150px;
    width:250px;
    left:1050px;

   }
</style>
<body bgcolor="#AFE4DE">


  <h1>  <b><u>Netflix. All Files</b></u></h1>
<table border="1">

    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Description</th>
        <th>Category</th>
        <th>File Name</th>
        <th>Video</th>
        <th>Action</th>

       
    </tr>
    @forelse ($netflix as $key=>$netflix)
        <tr>
            <td> {{$key+1}} </td>
            <td> {{$netflix->name}} </td>
            <td> {{$netflix->description}} </td>
            <td> {{$netflix->category}} </td>
            <td> {{$netflix->file_var}} </td>
            <td><video width="390" height="290" controls>
         <source src="{{ asset('uploads/' . $netflix->file_var) }}" type="video/mp4">
                   </video></td>
                   <td>
                    <button> <a href="destroy-file/{{$netflix->id}}">Delete</a></button>
                    <button> <a href="edit-file/{{$netflix->id}}">Edit/Update</a></button>
                  </td>
                   
                  
                        
                        </td>
             
        </tr>
     @empty
            no data found
     @endforelse


</table>


</body>
</html>